package day03;

public class Test3_OperatorDemo {

	public static void main(String[] args) {
		//�ֱ����1234�ĸ�λʮλ��λǧλ
		int a = 1234;
		System.out.println(a/1000);
		System.out.println(a%1000/100);
		System.out.println(a/10%10);
		System.out.println(a%10);
	}

}
